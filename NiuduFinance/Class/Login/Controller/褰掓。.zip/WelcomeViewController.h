//
//  WelcomeViewController.h
//  NiuduFinance
//
//  Created by liuyong on 16/3/18.
//  Copyright © 2016年 liuyong. All rights reserved.
//

#import "BaseViewController.h"

@interface WelcomeViewController : BaseViewController

@end
